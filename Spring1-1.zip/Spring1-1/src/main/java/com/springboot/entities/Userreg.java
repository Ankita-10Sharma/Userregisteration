package com.springboot.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
public class Userreg {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int  id;
	
	@NotBlank(message="Username cant be empty !!")
	@Size(min=3,max=12,message="Username must be bw 3 to 13 chars")
	private String username;
	
	@Pattern(regexp="^[a-zA-Z0-9.$]+@[a-zA-Z0-9]+.[a-zA-Z]{2}",message="invalid email")
	private String email;
	private String pass;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	@Override
	public String toString() {
		return "Userreg [id=" + id + ", username=" + username + ", email=" + email + ", pass=" + pass + "]";
	}
	public Userreg(int id, String username, String email, String pass) {
		super();
		this.id = id;
		this.username = username;
		this.email = email;
		this.pass = pass;
	}
	public Userreg() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
