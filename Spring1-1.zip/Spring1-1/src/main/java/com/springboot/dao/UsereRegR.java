package com.springboot.dao;

import org.springframework.data.repository.CrudRepository;

import com.springboot.entities.Userreg;

public interface UsereRegR extends CrudRepository<Userreg,Integer>{

	public Userreg findAllByUsername(String username);
}
