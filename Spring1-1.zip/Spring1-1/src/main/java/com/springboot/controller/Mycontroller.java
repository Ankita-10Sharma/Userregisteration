package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.entities.Userreg;
import com.springboot.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/user")
public class Mycontroller {

	@Autowired
	private UserService us;
	
	@GetMapping("/form")
	public ModelAndView form() {
		ModelAndView mv=new ModelAndView();
		mv.setStatus(HttpStatus.OK);
		mv.setViewName("form");
		return mv;
	}
	@PostMapping("/register")
	public ModelAndView process(@Valid @ModelAttribute Userreg ur,BindingResult br) {
		
		this.us.addUser(ur);
		ModelAndView mv1=new ModelAndView();
		
//		System.out.println(ur);
		mv1.addObject("m",ur);
		
		mv1.setStatus(HttpStatus.OK);
		mv1.setViewName("submit");
		if(br.hasErrors()) {
			System.out.println(br);	
			mv1.setViewName("form");
			return mv1;
			} 
		return mv1;
	}
	
//	@GetMapping("/fetch")
//	public ModelAndView proc(@RequestParam("username") String ue) {
//		Userreg u = this.us.getAllUsers(ue);
//		ModelAndView mv1=new ModelAndView();
//		mv1.addObject("u",u);
//		mv1.setStatus(HttpStatus.OK);
//		mv1.setViewName("all_user");
//		
//		return mv1;
//	}
	
	@GetMapping("/fetch")
	public ResponseEntity<?> fetchUserDetails(@RequestParam String username) {
	    try {
	        // Fetch user from the database
	        Userreg user = (Userreg) this.us.getAllUsers(username);
	        
	        if (user != null) {
	            return ResponseEntity.ok(user);
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
	        }
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to fetch user details.");
	    }
	}

}
