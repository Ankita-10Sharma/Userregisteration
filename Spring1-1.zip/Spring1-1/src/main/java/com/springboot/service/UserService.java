package com.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.dao.UsereRegR;
import com.springboot.entities.Userreg;

@Service
public class UserService {

	@Autowired
	private UsereRegR ur;
	
	public void addUser(Userreg u) {
		this.ur.save(u);
	}
	
	public List<Userreg> getAllUsers(String u){
		List<Userreg> us = (List<Userreg>) this.ur.findAllByUsername(u);
		return us;
	}
}
